const express = require('Express');
var app = express()
const hostname = 'localhost';
const port = 8000;

app.listen(port, hostname, function() {
  console.log('Server running at http://'+ hostname + ':' + port + '/');
});
